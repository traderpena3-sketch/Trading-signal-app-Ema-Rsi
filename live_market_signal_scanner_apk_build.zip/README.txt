LIVE MARKET SIGNAL SCANNER - APK BUILD PACKAGE

Files:
- buildozer.spec: Android build configuration
- PUT_YOUR_MAIN_PY_HERE.txt: Put your completed main.py in this folder as main.py

IMPORTANT:
1. Put your final main.py beside buildozer.spec.
2. In main.py set:
   API_KEY = "YOUR_TWELVE_DATA_API_KEY"
3. Build with Buildozer on Linux/WSL:
   buildozer android debug
4. The APK will normally appear in the bin/ folder.

For a release APK, configure signing before using it for distribution.

The app needs INTERNET permission because it reads market data from Twelve Data.
