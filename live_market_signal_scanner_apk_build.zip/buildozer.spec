[app]

# (str) Title of your application
title = Live Market Signal Scanner

# (str) Package name
package.name = marketscanner

# (str) Package domain
package.domain = org.marketscanner

# (str) Source code where main.py lives
source.dir = .

# (list) Source files to include
source.include_exts = py,png,jpg,jpeg,kv,atlas

# (str) Application version
version = 1.0

# (list) Python requirements
requirements = python3,kivy,requests

# (str) Supported orientation
orientation = portrait

# (bool) Fullscreen
fullscreen = 0

# (list) Permissions
android.permissions = INTERNET

# (str) Android API target
android.api = 35

# (str) Android minimum API
android.minapi = 21

# (str) Android NDK version
android.ndk = 27c

# (str) Android architecture
android.arch = arm64-v8a

# (bool) Use AndroidX
android.enable_androidx = True

# (str) Presplash
# presplash.filename = %(source.dir)s/presplash.png

# (str) Icon
# icon.filename = %(source.dir)s/icon.png

# (str) Python entry point
entrypoint = main.py

[buildozer]

# (str) Log level
log_level = 2

# (bool) Warn if running as root
warn_on_root = 1
