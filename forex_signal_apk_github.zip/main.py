import requests
from datetime import datetime
from zoneinfo import ZoneInfo

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner


# ==============================
# TWELVE DATA API KEY
# ==============================
API_KEY = "a4b71f98d4254425a6a55ab3aba678e1"


# ==============================
# SETTINGS
# ==============================
BASE_URL = "https://api.twelvedata.com/time_series"

PAIRS = [
    "EUR/USD",
    "GBP/USD",
    "USD/JPY",
    "USD/CHF",
    "AUD/USD",
    "USD/CAD",
    "NZD/USD",
]

INTERVALS = [
    "1min",
    "5min",
    "15min",
]


# ==============================
# EMA CALCULATION
# ==============================
def calculate_ema(values, period):
    if len(values) < period:
        return None

    multiplier = 2 / (period + 1)
    ema = sum(values[:period]) / period

    for price in values[period:]:
        ema = (price - ema) * multiplier + ema

    return ema


# ==============================
# MARKET DATA
# ==============================
def get_market_data(symbol, interval):
    params = {
        "symbol": symbol,
        "interval": interval,
        "outputsize": 100,
        "apikey": API_KEY,
        "format": "JSON",
    }

    response = requests.get(BASE_URL, params=params, timeout=15)
    response.raise_for_status()

    data = response.json()

    if "values" not in data:
        message = data.get("message", "Unable to get market data.")
        raise Exception(message)

    candles = data["values"]
    candles.reverse()

    closes = [float(candle["close"]) for candle in candles]

    if len(closes) < 21:
        raise Exception("Not enough candle data.")

    return candles, closes


# ==============================
# SIGNAL
# ==============================
def make_signal(closes):
    ema9 = calculate_ema(closes, 9)
    ema21 = calculate_ema(closes, 21)

    if ema9 is None or ema21 is None:
        return "WAIT", 50, ema9, ema21

    difference = abs(ema9 - ema21)
    reference = max(abs(ema21), 0.00001)
    strength = min((difference / reference) * 10000, 100)

    if ema9 > ema21:
        signal = "BUY"
        confidence = min(55 + strength, 95)
    elif ema9 < ema21:
        signal = "SELL"
        confidence = min(55 + strength, 95)
    else:
        signal = "WAIT"
        confidence = 50

    return signal, round(confidence), ema9, ema21


# ==============================
# APP
# ==============================
class ForexSignalApp(App):

    def build(self):
        root = BoxLayout(
            orientation="vertical",
            padding=20,
            spacing=12
        )

        title = Label(
            text="FOREX TRADING SIGNAL",
            font_size="25sp",
            size_hint_y=None,
            height=55
        )
        root.add_widget(title)

        self.pair_spinner = Spinner(
            text="EUR/USD",
            values=PAIRS,
            size_hint_y=None,
            height=50
        )
        root.add_widget(self.pair_spinner)

        self.interval_spinner = Spinner(
            text="1min",
            values=INTERVALS,
            size_hint_y=None,
            height=50
        )
        root.add_widget(self.interval_spinner)

        self.signal_label = Label(
            text="SIGNAL: WAIT",
            font_size="28sp",
            size_hint_y=None,
            height=65
        )
        root.add_widget(self.signal_label)

        self.price_label = Label(
            text="Price: --",
            font_size="19sp"
        )
        root.add_widget(self.price_label)

        self.confidence_label = Label(
            text="Confidence: --",
            font_size="19sp"
        )
        root.add_widget(self.confidence_label)

        self.ema_label = Label(
            text="EMA9: --   EMA21: --",
            font_size="17sp"
        )
        root.add_widget(self.ema_label)

        self.time_label = Label(
            text="Candle Time: --",
            font_size="16sp"
        )
        root.add_widget(self.time_label)

        self.status_label = Label(
            text="Ready",
            font_size="15sp"
        )
        root.add_widget(self.status_label)

        button = Button(
            text="GET SIGNAL",
            font_size="20sp",
            size_hint_y=None,
            height=60
        )
        button.bind(on_press=self.get_signal)
        root.add_widget(button)

        return root

    # ==============================
    # GET SIGNAL
    # ==============================
    def get_signal(self, instance):
        self.status_label.text = "Loading real market data..."

        try:
            symbol = self.pair_spinner.text
            interval = self.interval_spinner.text

            candles, closes = get_market_data(symbol, interval)

            signal, confidence, ema9, ema21 = make_signal(closes)

            latest_price = closes[-1]
            candle_time = candles[-1].get("datetime", "--")

            self.signal_label.text = f"SIGNAL: {signal}"
            self.price_label.text = f"Price: {latest_price}"
            self.confidence_label.text = f"Confidence: {confidence}%"

            if ema9 is not None and ema21 is not None:
                self.ema_label.text = (
                    f"EMA9: {ema9:.6f}   EMA21: {ema21:.6f}"
                )
            else:
                self.ema_label.text = "EMA9: --   EMA21: --"

            self.time_label.text = f"Candle Time: {candle_time}"
            self.status_label.text = (
                f"Updated: {datetime.now(ZoneInfo('Asia/Dhaka')).strftime('%Y-%m-%d %H:%M:%S')}"
            )

        except requests.exceptions.Timeout:
            self.status_label.text = "Error: API request timed out."
            self.signal_label.text = "SIGNAL: WAIT"

        except requests.exceptions.RequestException as e:
            self.status_label.text = f"Network error: {e}"
            self.signal_label.text = "SIGNAL: WAIT"

        except Exception as e:
            self.status_label.text = f"Error: {e}"
            self.signal_label.text = "SIGNAL: WAIT"


if __name__ == "__main__":
    ForexSignalApp().run()
