import requests
from datetime import datetime, timedelta

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner

API_KEY = "PUT_YOUR_NEW_TWELVE_DATA_API_KEY_HERE"
BASE_URL = "https://api.twelvedata.com/time_series"

PAIRS = ["EUR/USD", "GBP/USD", "USD/JPY", "USD/CHF", "AUD/USD", "USD/CAD", "NZD/USD"]
INTERVALS = ["1min", "5min", "15min"]

def calculate_ema(values, period):
    if len(values) < period:
        return None
    multiplier = 2 / (period + 1)
    ema = sum(values[:period]) / period
    for price in values[period:]:
        ema = (price - ema) * multiplier + ema
    return ema

def get_market_data(symbol, interval):
    params = {
        "symbol": symbol,
        "interval": interval,
        "outputsize": 100,
        "apikey": API_KEY,
        "format": "JSON",
    }
    response = requests.get(BASE_URL, params=params, timeout=15)
    response.raise_for_status()
    data = response.json()
    if "values" not in data:
        raise Exception(data.get("message", "Unable to get market data."))
    candles = data["values"]
    candles.reverse()
    closes = [float(c["close"]) for c in candles]
    if len(closes) < 21:
        raise Exception("Not enough candle data.")
    return candles, closes

def make_signal(closes):
    ema9 = calculate_ema(closes, 9)
    ema21 = calculate_ema(closes, 21)
    if ema9 is None or ema21 is None:
        return "WAIT", 50, ema9, ema21
    difference = abs(ema9 - ema21)
    reference = max(abs(ema21), 0.00001)
    strength = min((difference / reference) * 10000, 100)
    if ema9 > ema21:
        signal = "BUY"
        confidence = min(55 + strength, 95)
    elif ema9 < ema21:
        signal = "SELL"
        confidence = min(55 + strength, 95)
    else:
        signal = "WAIT"
        confidence = 50
    return signal, round(confidence), ema9, ema21

class ForexSignalApp(App):
    def build(self):
        root = BoxLayout(orientation="vertical", padding=20, spacing=12)

        root.add_widget(Label(text="FOREX TRADING SIGNAL", font_size="25sp",
                              size_hint_y=None, height=55))

        self.pair_spinner = Spinner(text="EUR/USD", values=PAIRS,
                                    size_hint_y=None, height=50)
        root.add_widget(self.pair_spinner)

        self.interval_spinner = Spinner(text="1min", values=INTERVALS,
                                        size_hint_y=None, height=50)
        root.add_widget(self.interval_spinner)

        self.signal_label = Label(text="SIGNAL: WAIT", font_size="28sp",
                                  size_hint_y=None, height=65)
        root.add_widget(self.signal_label)

        self.price_label = Label(text="Price: --", font_size="19sp")
        root.add_widget(self.price_label)

        self.confidence_label = Label(text="Confidence: --", font_size="19sp")
        root.add_widget(self.confidence_label)

        self.ema_label = Label(text="EMA9: --   EMA21: --", font_size="17sp")
        root.add_widget(self.ema_label)

        self.time_label = Label(text="Candle Time: --", font_size="16sp")
        root.add_widget(self.time_label)

        self.status_label = Label(text="Ready", font_size="15sp")
        root.add_widget(self.status_label)

        button = Button(text="GET SIGNAL", font_size="20sp",
                        size_hint_y=None, height=60)
        button.bind(on_press=self.get_signal)
        root.add_widget(button)
        return root

    def get_signal(self, instance):
        self.status_label.text = "Loading real market data..."
        try:
            symbol = self.pair_spinner.text
            interval = self.interval_spinner.text
            candles, closes = get_market_data(symbol, interval)
            signal, confidence, ema9, ema21 = make_signal(closes)
            latest = candles[-1]
            price = float(latest["close"])
            raw_time = latest["datetime"]

            try:
                candle_dt = datetime.fromisoformat(raw_time.replace("Z", "+00:00"))
                if candle_dt.tzinfo is None:
                    candle_dt = candle_dt + timedelta(hours=6)
                else:
                    candle_dt = candle_dt.astimezone(
                        datetime.now().astimezone().tzinfo
                    )
                formatted_time = candle_dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                formatted_time = raw_time

            self.signal_label.text = f"SIGNAL: {signal}"
            self.price_label.text = f"Price: {price:.5f}"
            self.confidence_label.text = f"Confidence: {confidence}%"
            self.ema_label.text = f"EMA9: {ema9:.5f}    EMA21: {ema21:.5f}"
            self.time_label.text = f"Candle Time: {formatted_time}"
            self.status_label.text = f"Live data: {symbol} | {interval}"

        except requests.exceptions.Timeout:
            self.status_label.text = "Connection timeout. Try again."
        except requests.exceptions.RequestException as e:
            self.status_label.text = f"Network error: {str(e)}"
        except Exception as e:
            self.status_label.text = f"Error: {str(e)}"

if __name__ == "__main__":
    ForexSignalApp().run()
