Before building: replace PUT_YOUR_NEW_TWELVE_DATA_API_KEY_HERE in main.py with a NEW API key. Do not reuse the key previously posted in chat; rotate/revoke it first.

Build command on a Linux/WSL machine with Buildozer installed:
buildozer android debug
